#include "value.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

typedef struct list{
  void *pointer;
  struct list* next;
} list;

list *mem_list;

void *talloc(size_t size){
  void* new_pointer = malloc(size);
  list *new_thing_pointer = malloc(sizeof(list));
  new_thing_pointer -> pointer = new_pointer;
  new_thing_pointer -> next = mem_list;
  mem_list = new_thing_pointer;
  return new_pointer;
}

void tfree(){
  while(!(mem_list == NULL)){
    list *next_thing = mem_list -> next;
    free(mem_list -> pointer);
    free(mem_list);
    mem_list = next_thing;
  }
}

void texit(int status){
  tfree();
  exit(status);
}

