#include "linkedlist.h"
#include "value.h"
#include "talloc.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

Value *makeNull(){
  Value *value = talloc(sizeof(Value));
  value -> type = NULL_TYPE;
  return(value);
}

Value *cons(Value *newCar, Value *newCdr){
  Value *value = talloc(sizeof(Value));
  value -> type = CONS_TYPE;
  value -> c.car = newCar;
  value -> c.cdr = newCdr;
  return(value);
}

// Print a single value, without a newline
void print(Value *value) {
  if (value -> type == INT_TYPE) {
    printf("%i", value -> i);
  }
  if (value -> type == DOUBLE_TYPE){
    printf("%f", value -> d);
  }
  if (value -> type == STR_TYPE){
    printf("%s", value -> s);
  }
  if (value -> type == CONS_TYPE){
    printf("( ");
    print(value -> c.car);
    printf(" . ");
    print(value -> c.cdr);
    printf(" )");
  }
}

// Display the contents of the linked list to the screen in some kind of
// readable format
void display(Value *list) {
  Value *currPos = list;
  while(!(currPos -> type == NULL_TYPE)){
    if(currPos -> type == CONS_TYPE) {
      print(currPos -> c.car);
      printf("\n");
      currPos = currPos -> c.cdr;
    }
    else{
      print(list);
      printf("\n");
    }
  }
}

// Return a new list that is the reverse of the one that is passed in. All
// content within the list should be duplicated; there should be no shared
// memory whatsoever between the original list and the new one.
//
// FAQ: What if there are nested lists inside that list?
// ANS: There won't be for this assignment. There will be later, but that will
// be after we've got an easier way of managing memory.
Value *reverse(Value *list){
  Value *currPos = list;
  Value *currHead = makeNull();
  while(!(currPos -> type == NULL_TYPE)) {
    assert(currPos -> type == CONS_TYPE);
    // Value *newCar = makeNull();
    // newCar -> type = currPos -> c.car -> type;
    // newCar -> i = currPos -> c.car -> i;
    // newCar -> d = currPos -> c.car -> d;
    // if (currPos -> c.car -> type == STR_TYPE){
    //   newCar -> s = talloc(sizeof(char)*(strlen(currPos -> c.car -> s) + 1));
    //   strcpy(newCar->s, currPos -> c.car -> s);
    // }
    currHead = cons(currPos -> c.car, currHead);
    currPos = currPos -> c.cdr;
  }
  return(currHead);
}


// Utility to make it less typing to get car value. Use assertions to make sure
// that this is a legitimate operation.
Value *car(Value *list){
  assert(list -> type == CONS_TYPE);
  return(list -> c.car);
}

// Utility to make it less typing to get cdr value. Use assertions to make sure
// that this is a legitimate operation.
Value *cdr(Value *list){
  assert(list -> type == CONS_TYPE);
  return(list -> c.cdr);
}

// Utility to check if pointing to a NULL_TYPE value. Use assertions to make sure
// that this is a legitimate operation.
bool isNull(Value *value){
  return((bool)(value -> type == NULL_TYPE));
}

// Measure length of list. Use assertions to make sure that this is a legitimate
// operation.
int length(Value *value){
  assert(value -> type == CONS_TYPE || value -> type == NULL_TYPE);
  int len = 0;
  Value *currPos = value;
  while (!(currPos -> type == NULL_TYPE)) {
    assert(currPos -> type == CONS_TYPE);
    len++;
    currPos = currPos -> c.cdr;
  }
  return len;
}
