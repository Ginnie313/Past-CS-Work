#include "value.h"
#include "linkedlist.h"
#include "talloc.h"
#include "tokenizer.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>

Value *addToParseTree(Value *tree, int *depth, Value *token){
  tree = cons(token, tree);
  int open = 0;
  Value *currPos = tree;
  //iterate through tree and count the number of open parens
  while (currPos -> type != NULL_TYPE){
    //printf("loop\n");
      if (car(currPos) -> type == OPEN_TYPE){
        //printf("we saw a (\n");
        open++;
      }
      currPos = cdr(currPos);
  }
  *depth = open;
  return tree;
}

Value *parse(Value *tokens) {
    Value *tree = makeNull();
    int depth = 0;

    Value *current = tokens;
    assert(current != NULL && "Error (parse): null pointer");
    while (current-> type != NULL_TYPE) {
      //printf("Loop\n");
        Value *new_list = makeNull();
        //grab every value before the last (, add it to a new list
        if (car(current) -> type == CLOSE_TYPE){
          if(depth == 0){
            printf("Syntax error: too many close parentheses");
            texit(1);            
          }
          else{
            //this is currently the problem loop

            while(car(tree) -> type != OPEN_TYPE){
            new_list = cons(car(tree), new_list);
            tree = cdr(tree);
            }

            //get rid of the last (
            tree = cdr(tree);
            //new_list = reverse(new_list);
            tree = cons(new_list, tree);
            depth--;

            //move to next token 
            current = cdr(current);
          }   
        }
        //otherwise, push token onto the stack
        else{
          //printf("New token: %s\n", car(current) -> s);
          Value *token = car(current);
          tree = addToParseTree(tree, &depth, token);
          current = cdr(current);
        }
    }
    if (depth != 0) {
        printf("Syntax error: not enough close parentheses");
        texit(1);
    }
  tree = reverse(tree); 
  return tree;  
}

void printTree(Value *tree){
  //printf("recursive call made");
  Value *current = tree;
  while (current -> type != NULL_TYPE){
    //printf("how many times\n");
    if (current -> type == CONS_TYPE){
      //printf("in the cons");
      if (car(current) -> type == CONS_TYPE){
        printf("(");
        printTree(car(current));
        //if(cdr(current) -> type != NULL_TYPE){
         // printTree(cdr(current));
        //}
      printf(")");
      //printf("a");
      }
      else if (car(current) -> type == INT_TYPE){
        //printf("i");
        printf("%d", car(current) -> i);
      }

      else if (car(current) -> type == DOUBLE_TYPE){
        //printf("d");
        printf("%lf", car(current) -> d);
      }
      else{
        //printf("a");
        if (car(current) -> type != NULL_TYPE){
          //printf("Type: %u", car(current) -> type);
          printf("%s", car(current) -> s);
        }
        else{
          printf("%s", "()");
        }
        }
      }
      printf(" ");
      current = cdr(current);
    }
}
