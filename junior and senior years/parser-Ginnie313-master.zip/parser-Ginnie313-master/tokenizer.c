#include "value.h"
#include "linkedlist.h"
#include "talloc.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>


void processToken(Value *token){
  char *ptr;
  if (token -> type == INT_TYPE){
    token -> i = strtol(token -> s, &ptr, 10);
  }
  else if(token -> type == DOUBLE_TYPE) {
    token -> d = strtod(token -> s, &ptr);
  }
}

void printValue(Value value){
  char *type_string;
  switch(value.type) {
    case BOOL_TYPE:
      type_string = "boolean";
      printf("%s", value.s);
      break;
    case INT_TYPE:
      type_string = "integer";
      printf("%d", value.i);
      break;
    case DOUBLE_TYPE:
      type_string = "double";
      printf("%lf", value.d);
      break;
    case STR_TYPE:
      type_string = "string";
      printf("%s", value.s);
      break;
    case SYMBOL_TYPE:
      type_string = "symbol";
      printf("%s", value.s);
      break;
    case OPEN_TYPE:
      type_string = "open";
      printf("%s", value.s);
      break;
    case CLOSE_TYPE:
      type_string = "close";
      printf("%s", value.s);
      break;
    case NULL_TYPE:
      // something went wrong
      type_string = "null";
      printf("Error: null token\n");
      texit(100);
      break;
    case PENDING_TYPE:
      //something went wrong differently
      type_string = "pending";
      printf("Error: unfinished token\n");
      texit(101);
      break;
    default:
      //something went very wrong
      type_string = "oops";
      printf("Error: untyped token\n");
      texit(102);
      break;
  }
  printf(":%s\n", type_string);
}

void displayTokens(Value *list) {
  Value *currPos = list;
  while(!(currPos -> type == NULL_TYPE)){
    printValue(*currPos -> c.car);
    currPos = currPos -> c.cdr;
  }
}

Value *tokenize() {
    char charRead;
    Value *list = makeNull();
    charRead = (char)fgetc(stdin);
    bool haveToken = false; //does our token hold any useful info
    Value *currentValue = makeNull();
    bool finishable = true;
    bool inComment = false;
    const char punctuation[] = "!$%&*/:<=>?~_^";
    char *ret;
    //int iterCount = 0;
    
    while (charRead != EOF){
      //printf("%c  %i\n", charRead, iterCount);
      //iterCount++;
      //working on existing
      if (inComment) {
        if (charRead == '\n') {
          inComment = false;
        }
      }
      else{
        if(haveToken) {
          //printf("We have a token! It is ");
          //printValue(*currentValue);
          if (currentValue -> type == STR_TYPE){
            //we see the end of the string
            if (charRead == '"'){
              currentValue -> s = strncat(currentValue -> s,  
                                          &charRead,
                                          1);
              list = cons(currentValue, list);
              //create a new current token and update the pointer
              Value *nextValue = makeNull();
              currentValue = nextValue;
              haveToken = false;
            }
            //we see continuing characters in a string
            else {
              currentValue -> s = strncat(currentValue -> s,  
                                          &charRead,
                                          1);  
            }
            //we run off the edge--probably just means this token doesn't get added
          }
          //You saw a ( or ), drop everything
          else if ((charRead == ')') || (charRead == '(')){
            if (finishable){
              processToken(currentValue);
              list = cons(currentValue, list);
              Value *parenValue = makeNull();
              parenValue -> s = talloc(2*sizeof(char));
              strcpy(parenValue -> s, "");
              strncat(parenValue -> s, &charRead, 1);
              if(charRead == '(') {
                parenValue -> type = OPEN_TYPE;
              }
              else if (charRead == ')') {
                parenValue -> type = CLOSE_TYPE;
              }
              list = cons(parenValue, list);
            //create a new current token and update the pointer
              Value *nextValue = makeNull();
              currentValue = nextValue;
              haveToken = false;
            }
            else{
              printf("Error: Parentheses interrupt");
              texit(1);
            }
          }
          //we have a + or -
          else if (currentValue -> type == PENDING_TYPE){
            //it's by itself, so symbol
            if (charRead == ' ' || charRead == '\n'){
              list = cons(currentValue, list);
              //create a new current token and update the pointer
              Value *nextValue = makeNull();
              currentValue -> type = SYMBOL_TYPE;
              currentValue = nextValue;
              haveToken = false;
            }
            else if (isdigit(charRead)){
              currentValue -> type = INT_TYPE;
              //currentValue -> s = talloc(301*sizeof(char));
              //strcpy(currentValue -> s, "");
              strncat(currentValue -> s, &charRead, 1);
            }
            else if (charRead == '.') {
              finishable = false;
              currentValue -> type = DOUBLE_TYPE;
              currentValue -> s = strcat(currentValue -> s,  
                                          &charRead);
                                          
            }
            else if (charRead == ';') {
              currentValue -> type = SYMBOL_TYPE;
              list = cons(currentValue, list);
              Value *nextValue = makeNull();
              currentValue = nextValue;
              inComment = true;
            }
            else {
              printf("Error: sign followed by improper character: %c\n", charRead);
              texit(10);
            }
          }
          else if (charRead == ';'){
            if(finishable) {
              processToken(currentValue);
              list = cons(currentValue, list);
              //create a new current token, update the pointer, and drop everything
              Value *nextValue = makeNull();
              currentValue = nextValue;
              haveToken = false;
              inComment = true;
            }
            else {
              printf("Error: unfinished token followed by semicolon\n");
              texit(1);
            }
          }
          //whitespace?
          else if (charRead == ' ' || charRead == '\n'){
            if(finishable) {
              processToken(currentValue);
              list = cons(currentValue, list);
              //create a new current token and update the pointer
              Value *nextValue = makeNull();
              currentValue = nextValue;
              haveToken = false;
            }
            else {
              printf("Error: unfinished token followed by space\n");
              texit(1);
            }
          }
          else if (currentValue -> type == BOOL_TYPE) {
            if(charRead == 'f' || charRead == 't') {
              if(finishable == false) {
                currentValue -> s = strncat(currentValue -> s,  
                                            &charRead,
                                            1);
                finishable = true;
              }
              else {
                printf("Error: overlong boolean token\n");
                texit(2);
              }
            }
            else {
              printf("Error: boolean neither #t nor #f\n");
              texit(3);
            }
          }
          else if (currentValue -> type == SYMBOL_TYPE){
            ret = strchr(punctuation, charRead);
            if (isalpha(charRead) || !(ret== NULL) || isdigit(charRead)                       || charRead == '.' || charRead == '+'                       || charRead == '-') {
              currentValue -> s = strncat(currentValue -> s,  
                                          &charRead,
                                          1);
            }
            else {
              //printf("Here's the char: %c", charRead);
              printf("Error: symbol broken by %c\n", charRead);
              texit(4);
            }
          }
          else if (currentValue -> type == INT_TYPE){
            if (isdigit(charRead)){
              currentValue -> s = strncat(currentValue -> s,  
                                          &charRead,
                                          1);
            }
            else if (charRead == '.') {
              currentValue -> type = DOUBLE_TYPE;
              // currentValue -> s = talloc(301*sizeof(char));
              // strcpy(currentValue -> s, "");
              currentValue -> s = strncat(currentValue -> s,  
                                          &charRead,
                                          1);
            }
            else {
              printf("Error: integer broken by something\n");
              texit(5);
            }
          }
          else if (currentValue -> type == DOUBLE_TYPE){
            if(isdigit(charRead)) {
              finishable = true;
              
              currentValue -> s = strncat(currentValue -> s,  
                                          &charRead,
                                          1);
            }
            else {
              printf("Error: float broken by something\n");
              texit(6);
            }
          }
        }
        //no current token exists
        else{
          ret = strchr(punctuation, charRead);
          if (charRead == '"') {
            currentValue -> s = talloc(301*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = STR_TYPE;
            haveToken = true;
          }
          //beginning of a comment
          else if (charRead == ';'){
          // either in a comment or you did something wrong
            inComment = true;
          }
          
          else if (charRead == '(') {
            currentValue -> s = talloc(2*sizeof(char));
            strcpy(currentValue -> s,"");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = OPEN_TYPE;
            list = cons(currentValue, list);
            //create a new current token and update the pointer
            Value *nextValue = makeNull();
            currentValue = nextValue;
          }
          else if (charRead == ')') {
            currentValue -> s = talloc(2*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = CLOSE_TYPE;
            list = cons(currentValue, list);
            //create a new current token and update the pointer
            Value *nextValue = makeNull();
            currentValue = nextValue;
          }
          else if(charRead == ' ' || charRead == '\n') {
            //void(0); //do nothing if you have two spaces in a row
            ;
          }
          //We see the start of a bool
          else if (charRead == '#'){
            currentValue -> s = talloc(3*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = BOOL_TYPE;
            finishable = false;
            haveToken = true;
          }
          //We've seen an alphabetical character or punctuation
          else if (isalpha(charRead) || !(ret== NULL)){
            currentValue -> s = talloc(301*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = SYMBOL_TYPE;
            haveToken = true;
          }
          //We've seen a number
          else if (isdigit(charRead)) {
            currentValue -> s = talloc(301*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = INT_TYPE;
            haveToken = true;
          }
          else if (charRead == '+' || charRead == '-') {
            //plus or minus code, could go a few directions
            currentValue -> s = talloc(301*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = PENDING_TYPE;
            haveToken = true;
          }

          //we read a ., it's a double
          else if (charRead == '.'){
            currentValue -> s = talloc(301*sizeof(char));
            strcpy(currentValue -> s, "");
            strncat(currentValue -> s, &charRead, 1);
            currentValue -> type = DOUBLE_TYPE;
            haveToken = true;
            finishable = false;
          }
          //we didn't see any of the above
          else{
            printf("Error: Improper character: %c \n", charRead);
              texit(10);
          }
        }
      }
      charRead = (char)fgetc(stdin);
    }

    Value *revList = reverse(list);
    return revList;
}