For this assignment, I collaborated with:

Partner: Ryan Becker
