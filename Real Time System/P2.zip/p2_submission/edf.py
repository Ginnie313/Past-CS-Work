#!/usr/bin/env python

"""
edf.py - Earliest Deadline First scheduler

EdfPriorityQueue: priority queue that prioritizes by absolute deadline
EdfScheduler: scheduling algorithm that executes EDF (preemptive)

Modified by Ginnie White and Ryan Becker
"""

import json
import sys

from taskset import *
from scheduleralgorithm import *
from schedule import ScheduleInterval, Schedule
from display import SchedulingDisplay

class EdfPriorityQueue(PriorityQueue):
    def __init__(self, jobReleaseDict):
        """
        Creates a priority queue of jobs ordered by absolute deadline.
        """
        PriorityQueue.__init__(self, jobReleaseDict)

    def _sortQueue(self):
        # EDF orders by absolute deadline
        self.jobs.sort(key = lambda x: (x.deadline, x.task.id, x.id))


    def _findFirst(self, t):
        """
        Returns the index of the highest-priority job released at or before t,
        or -1 if the queue is empty or if all remaining jobs are released after t.
        """
        if self.isEmpty():
            return -1

        currentJobs = [(i, job) for (i,job) in enumerate(self.jobs) if job.releaseTime <= t]
        if len(currentJobs) == 0:
            return -1

        currentJobs.sort(key = lambda x: (x[1].deadline, x[1].task.id, x[1].id))
        return currentJobs[0][0] # get the index from the tuple in the 0th position


    def popNextJob(self, t):
        """
        Removes and returns the highest-priority job of those released at or after t,
        or None if no jobs are released at or after t.
        """
        laterJobs = [(i, job) for (i,job) in enumerate(self.jobs) if job.releaseTime >= t]

        if len(laterJobs) == 0:
            return t

        laterJobs.sort(key = lambda x: (x[1].releaseTime, x[1].deadline, x[1].task.id))
        return self.jobs.pop(laterJobs[0][0]) # get the index from the tuple in the 0th position

    def popPreemptingJob(self, t, job):
        """
        Removes and returns the job that will preempt job 'job' after time 't', or None
        if no such preemption will occur (i.e., if no higher-priority jobs
        are released before job 'job' will finish executing).

        t: the time after which a preemption may occur
        job: the job that is executing at time 't', and which may be preempted
        """
        if job is None:
            return None

        hpJobs = [(i, j) for (i,j) in enumerate(self.jobs) if \
                  ((j.deadline < job.deadline or (j.deadline == job.deadline and j.task.id < job.task.id)) and \
                    j.releaseTime > t and j.releaseTime < t + job.remainingTime)]

        if len(hpJobs) == 0:
            return None

        hpJobs.sort(key = lambda x: (x[1].releaseTime, x[1].deadline, x[1].task.id))
        return self.jobs.pop(hpJobs[0][0]) # get the index from the tuple in the 0th position

class EdfScheduler(SchedulerAlgorithm):
    def __init__(self, taskSet):
        SchedulerAlgorithm.__init__(self, taskSet)

    def buildSchedule(self, startTime, endTime):
        self._buildPriorityQueue(EdfPriorityQueue)

        time = 0.0
        self.schedule.startTime = time

        previousJob = None
        didPreemptPrevious = False

        #Loop until the priority queue is empty, executing jobs preemtively nearest deadline
        while not self.priorityQueue.isEmpty():

            interval, newJob = self._makeSchedulingDecision(time, previousJob)

            nextTime = interval.startTime
            didPreemptPrevious = interval.didPreemptPrevious

            if previousJob is not None:
                #If there is a preemption:
                if didPreemptPrevious:
                    previousJob.execute(nextTime - time)
                    self.priorityQueue.addJob(previousJob)
                #If no preempting job
                else:
                    previousJob.executeToCompletion()

            self.schedule.addInterval(interval)

            time = nextTime
            previousJob = newJob

        if previousJob is not None:
            time += previousJob.remainingTime
            previousJob.executeToCompletion()

        finalInterval = ScheduleInterval()
        finalInterval.intialize(time, None, False)
        self.schedule.addInterval(finalInterval)

        #Post-process intervals

        latestDeadline = max([job.deadline for job in self.taskSet.jobs])
        endTime = max(time + 1.0, latestDeadline, float(endTime))
        self.schedule.postProcessIntervals(endTime)

        return self.schedule

    def _makeSchedulingDecision(self, t, previousJob):

        current_t = t
        interval = ScheduleInterval()

        doesPreempt = False

        if previousJob == None: #no previous job
            newJob = self.priorityQueue.popNextJob(t)
            current_t = newJob.releaseTime
        else: #there was a previous job

            potentialJob = self.priorityQueue.popPreemptingJob(t, previousJob)

            if potentialJob != None:
            #Preemption - Yes
                doesPreempt = True
                newJob = potentialJob
                current_t = newJob.releaseTime
            else:
            #Preemption - No
                current_t = t + previousJob.remainingTime
                newJob = self.priorityQueue.popFirst(current_t)

        if newJob == None:
            interval.intialize(current_t, newJob, False)
            return interval, newJob

        else:
            interval.intialize(current_t, newJob, doesPreempt)
            return interval, newJob

if __name__ == "__main__":
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    else:
        file_path = "tasksets/hwp1_test3.json"

    with open(file_path) as json_data:
        data = json.load(json_data)

    taskSet = TaskSet(data)

    taskSet.printTasks()
    taskSet.printJobs()

    edf = EdfScheduler(taskSet)
    schedule = edf.buildSchedule(0, 6)

    schedule.printIntervals(displayIdle=True)

    print("\n// Validating the schedule:")
    schedule.checkWcets()
    schedule.checkFeasibility()

    display = SchedulingDisplay(width=800, height=480, fps=33, scheduleData=schedule)
    display.run()
