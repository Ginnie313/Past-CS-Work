#!/usr/bin/env python

"""
schedule.py - parser/serializer for schedule to/from JSON file

Modified for P1 by Ginnie White, 1/13/2020
"""

import json
import sys

from taskset import TaskSet

class ScheduleJsonKeys(object):
    # Schedule
    KEY_SCHEDULE = "scheduleOutput"
    KEY_SCHEDULE_START = "startTime"
    KEY_SCHEDULE_END = "endTime"

    # Time intervals
    KEY_INTERVALS = "intervals"
    KEY_INTERVAL_START = "timeInstant"
    KEY_INTERVAL_TASKID = "taskId"
    KEY_INTERVAL_JOBID = "jobId"
    KEY_INTERVAL_DIDPREEMPT = "didPreempt"

class Schedule(object):
    def __init__(self, data, taskSet):
        if ScheduleJsonKeys.KEY_SCHEDULE not in data:
            print("Error: Missing schedule info")
            return

        scheduleData = data[ScheduleJsonKeys.KEY_SCHEDULE]
        self.startTime = float(scheduleData[ScheduleJsonKeys.KEY_SCHEDULE_START])
        self.endTime = float(scheduleData[ScheduleJsonKeys.KEY_SCHEDULE_END])

        self.taskSet = taskSet

        self.parseDataToIntervals(scheduleData, taskSet)

    def parseDataToIntervals(self, scheduleData, taskSet):
        intervals = []

        for intervalData in scheduleData[ScheduleJsonKeys.KEY_INTERVALS]:
            interval = ScheduleInterval(intervalData)
            intervals.append(interval)

        # Post-process the intervals, setitng the end time and whether
        # the job was completed based on the following interval
        for (i, interval) in enumerate(intervals):
            if i < len(intervals) - 1:
                nextInterval = intervals[i+1]
                interval.updateIntervalEnd(nextInterval.startTime, not nextInterval.didPreemptPrevious)
            else:
                interval.updateIntervalEnd(self.endTime, False)

        self.intervals = intervals

    def printIntervals(self, displayIdle=True):
        print("\nScheduling intervals:")
        for interval in self.intervals:
            if not interval.isIdle() or displayIdle:
                print(interval)

    def areWcetsExceeded(self):
        """
        Returns a boolean indicating whether all jobs execute for
        at most their WCET value.

        A note on implementation: I did not change the name of the function.
        Returns False if Wcets are exceeded, true otherwise.
        """
        for task in self.taskSet:
            wcet = task.wcet
            for job in task.getJobs():
                execute_time = 0
                for interval in self.intervals:
                    #Calculate job's total execution time over every interval
                    if interval.taskId == task.id and interval.jobId == job.id:
                        execute_time += (interval.endTime - interval.startTime)
                if execute_time > wcet: #Job exceeds its WCET
                    return False
        return True #All jobs meet the parameters

    def checkWcets(self):
        areWcetsExceeded = self.areWcetsExceeded()
        if areWcetsExceeded:
            print("No WCETs are exceeded")
        else:
            print("A job exceeds its WCET :(")

    def doesMeetDeadlines(self):
        """
        Returns a boolean indicating whether all deadlines are met.
        """

        for task in self.taskSet:
            for job in task.getJobs():
                job_deadline = job.deadline
                interval_end_times = [] #empty list to hold the end times of every interval
                for interval in self.intervals:
                    if interval.taskId == task.id and interval.jobId == job.id:
                        interval_end_times.append(interval.endTime)
                if max(interval_end_times) > job_deadline: #if the last (ie, highest end time) interval for the job finsishes after the deadline
                    return False
        return True #All jobs meet the parameters

    def checkFeasibility(self):
        doesMeetDeadlines = self.doesMeetDeadlines()
        if doesMeetDeadlines:
            print("This schedule is feasible!")
        else:
            print("This schedule is not feasible :(")

class ScheduleInterval(object):
    def __init__(self, intervalDict):
        self.startTime = float(intervalDict[ScheduleJsonKeys.KEY_INTERVAL_START])
        self.taskId = int(intervalDict[ScheduleJsonKeys.KEY_INTERVAL_TASKID])
        self.jobId = int(intervalDict[ScheduleJsonKeys.KEY_INTERVAL_JOBID])
        self.didPreemptPrevious = bool(intervalDict[ScheduleJsonKeys.KEY_INTERVAL_DIDPREEMPT])

    def updateIntervalEnd(self, endTime, didJobComplete):
        self.endTime = endTime
        self.jobCompleted = didJobComplete and not self.taskId == 0 # "idle" jobs don't complete

    def isIdle(self):
        return self.taskId == 0

    def __str__(self):
        if not self.isIdle():
            return "interval [{0},{1}): task {2}, job {3} (completed: {4}, preempted previous: {5})".format(self.startTime, self.endTime, self.taskId, self.jobId, self.jobCompleted, self.didPreemptPrevious)
        else:
            return "interval [{0},{1}): IDLE (completed: {2}, preempted previous: {3})".format(self.startTime, self.endTime, self.jobCompleted, self.didPreemptPrevious)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    else:
        file_path = "tasksets/hwp1_test1.json"

    with open(file_path) as json_data:
        data = json.load(json_data)

    taskSet = TaskSet(data)

    taskSet.printTasks()
    taskSet.printJobs()

    schedule = Schedule(data, taskSet)

    schedule.printIntervals(displayIdle=True)

    print("\n// Validating the schedule:")
    schedule.checkWcets()
    schedule.checkFeasibility()
