For P1, I did not collaborate with anyone in writing the code and I did not discuss the code with anyone.
