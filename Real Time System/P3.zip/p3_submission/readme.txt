For this assignment, I worked alone

Answers to problem 3:

The three lines here represent three different kinds of task utilization distributions.
The light line represents task sets where each task has a utilization between 0.001 and 0.01,
the medium-light line represents task sets where each task has a utilization between 0.01--0.1,
and the medium line represents task sets where each task has a utilization between 0.1 and 0.4.

The medium line drops off later than the others. Because each task in these sets has more utilization, the medium line has the least tasks out of all the distributions.
Consequently, the medium line has the highest U_lub bound for RM.

The light line drops off earliest. Because each task in these sets has a very low utilization,
task sets represented by the light line have far more tasks than sets in the other two lines.
As a result, the light line's U_lub for RM is lowest.

I think that the medium line represents the best schedulability because the curve
takes the longest to drop off. This means that we can utilize more of our system before
increasing numbers of potential task sets start to become unschedulable.
