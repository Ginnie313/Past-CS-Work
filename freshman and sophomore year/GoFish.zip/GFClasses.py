'''Erika Mitchell and Ginnie White
Written March 8th 2018
This is code that creates all the card-related classes for Go Fish 
and has the play method that runs most of the game'''

#imports the modules
import random
import GF_interfaces


class Card:
    #Is a class creates a card oject. Each card object contains a value.
    
    def __init__(self, ivalue):
        self.value = ivalue
        
    #This method return the value of the card object.
    def get_value(self):
        return self.value
    
        
class Hand:
    '''This is a class that simulates aplayer's hand. It contains a list of cards
    that are the cards in the hand.'''
    
    def __init__(self):
        self.cards = []
        
    def add_card(self, icard):
        #This method adds a card to the hand's list of cards in the hand object.
        self.cards.append(icard)
        
    def get_card(self, inum):
        '''This method has a parameter that is an index, which indexs a card in the 
        \hand and returns that card.'''
        card = self.cards[inum]
        return card
        
    def num_cards(self):
        #This method counts the number of cards in the hand.
        return len(self.cards)
        
    def remove_card(self, icard):
        #This method takes a card object as a parameter and removes that card from the hand.
        self.cards.remove(icard)
          
    def show_cards(self):
        '''This method creates a list that contains all the values of the of the card
        objects in the hand.'''
        value_list = []
        
        for item in self.cards:
            value = item.get_value()
            value_list.append(value)
            
        return value_list

    def cards_values(self, ivalue):
        '''This method determines if a card object with a certain value is in
        the hand that it is searching, if it is not the method returns negative 
        1, else it returns a list containing the indexes of the cards.'''
        
        i = 0
        
        card_idx_list = []
        for item in self.cards:
            value = item.get_value()
            
            if ivalue == value:
                card_idx_list.append(i)
            i += 1
    
        print("card_idx_list:", card_idx_list)
        inum = len(card_idx_list)
        print("inum:", inum)
        
        if inum == 0:
            return -1
        
        else:
            return card_idx_list
                
    def create_book(self):
        '''This method will check a hand for 4 cards of the same value, if there 
        are 4 cards the computer will return 1 point and remove the matching cards
        from the list by assigning a list without those cards to the list in the
        hand object.'''
        points = 0
        empty_list = []
        for item in self.cards:
            count = self.cards.count(item)
            if count == 4:
                points = 1
                
            else:
                empty_list.append(item)
        self.cards = empty_list        
    
        return points
    
    
class Player:
    #This object contains a score.
    def __init__(self):
        self.score = 0
        
    def get_score(self):
        #This method returns the score.
        return self.score

    def add_score(self, points):
        '''This method adds more points (new points are parameters) to the score by 
        reassigning the score in the object.'''
        score = self.get_score()
        new_score = score + points
        self.score = new_score

    def ask_card(self, player_hand, computer_hand, game_deck):
        '''This method takes in three parameters a hand, another hand, and a deck. It checks
        the player's hand to see if it has zero cards if so it gives 5 cards from the deck or 
        less that 5 if there are less that five cards in the deck. It lets the player input the
        card they want to ask for and checks to see if they have that card in there hand. 
        Once the player asks for a card that they do have Python checks the computer's hand 
        to see if it has that card it is removed from the computer's hand and added to 
        the player's hand, if not the player is given a card from the deck.'''

        if len(player_hand.cards) == 0 and len(game_deck.card_deck) >= 5:
            print("You ran out of cards. Here are 5 from the deck.")
            for i in range(1, 6):
                idx = game_deck.rando()
                if idx != False:
                    card = game_deck.get_card(idx)
                    player_hand.add_card(card)
                    game_deck.remove_card(idx)
                
        elif len(player_hand.cards) == 0 and len(game_deck.card_deck) < 5:
            for i in range(1, len(game_deck.card_deck)):
                idx = game_deck.rando()
                if idx != False:
                    card = game_deck.get_card(idx)
                    player_hand.add_card(card)
                    game_deck.remove_card(idx)
                    return
        
        item_found = False
        
        while item_found == False:
            ivalue = input("What card would you like to ask for? ")
            ivalue = int(ivalue)
            for item in player_hand.cards:
                a = item.get_value()
                if a == ivalue:
                    item_found = True
        added_items = []
        new_list = []
        
        for item in computer_hand.cards:
            val = item.get_value()
            if val == ivalue:
                added_items.append(item)
            else:
                new_list.append(item)
                
        if len(added_items) != 0: 
            print("You swiped a", ivalue, "from the computer.")
            for item in added_items:
                player_hand.cards.append(item)
                computer_hand.cards = new_list
                
        if len(added_items) == 0:
            print("They did not have that card. Go Fish!")
            inum = game_deck.rando()
            if len(game_deck.card_deck) != 1:
                new_card = game_deck.get_card(inum)
                player_hand.cards.append(new_card)
                game_deck.remove_card(inum)
            if len(game_deck.card_deck) == 1:
                last_card = game_deck.get_card(0)
                game_deck.remove_card(0)
                player_hand.add_card(last_card)
                
            
class Computer:
    #The computer is an object that contains a score.
    def __init__(self):
        self.score = 0
        
    def get_score(self):
        #This method returns the score of the computer.
        return self.score
    
    def add_score(self, points):
        #This method updates the score by adding new points to it.
        score = self.get_score()
        new_score = score + points
        self.score = new_score
    
    def choose_card(self, computer_hand, game_deck):
        '''This method takes two parameter the computer's hand and the deck. It checks 
        to see if the computer has more than 0 cards. If the computer has 0 cards it
        will give it some cards. It will check to see if the computer's hand contains
        multiples of any cards. If it does it will return one of the values that is a
        multiple else it will return a random value. '''
        if len(game_deck.card_deck) == 0:
            return
        if len(game_deck.card_deck) != 0:
            if len(computer_hand.cards) == 0:
                print("The computer ran out of cards and took five from the deck.")
                for i in range(1, 6):
                    idx = game_deck.rando()
                    if idx != False:
                        card = game_deck.get_card(idx)
                        computer_hand.add_card(card)
                        game_deck.remove_card(idx)
            
            elif len(computer_hand.cards) == 0 and len(game_deck.card_deck) < 5:
                for i in range(1, len(game_deck.card_deck)):
                    idx = game_deck.rando()
                    if idx != False:
                        card = game_deck.get_card(idx)
                        computer_hand.add_card(card)
                        game_deck.remove_card(idx)
        
            value_list_2 = []
            value_list_3 = []
            for item in computer_hand.cards:
                count = computer_hand.cards.count(item)
                if count == 2:
                    val = item.get_value()
                    value_list_2.append(val)
                
                elif count == 3:
                    val = item.get_value()
                    value_list_3.append(val)
                    
                else:
                    continue
                
            if len(value_list_3) == 1:
                return value_list_3[0]
        
            elif len(value_list_3) > 1:
                idx = random.randint(0, len(value_list_3) - 1)
                return value_list_3[idx]
        
            elif len(value_list_2) == 1:
                return value_list_2[0]
        
            elif len(value_list_2) > 1:
                idx = random.randint(0, len(value_list_2) - 1)
                return value_list_2[idx]
    
            else:
                idx = random.randint(0, len(computer_hand.cards) - 1)
                icard = computer_hand.get_card(idx)
                val = icard.get_value()
                return val
        
    def ask_card(self, player_hand, computer_hand, game_deck, ivalue):
        '''This method takes 4 parameters player_hand, computer_hand, game_deck,
        and ivalue. It checks to see if the value that it is asking for is in the
        player's hand, if it is the card is added to the computer's hand and
        removed from the player's hand, if not the computer draws a card from the deck.'''
        
        print("The computer asked for a", ivalue,".")
        
        added_items = []
        new_list = []
        
        for item in player_hand.cards:
            val = item.get_value()
            if val == ivalue:
                added_items.append(item)
            else:
                new_list.append(item)
                
                
        if len(added_items) != 0:        
            for item in added_items:
                computer_hand.cards.append(item)
                player_hand.cards = new_list
                print("You had that card(s), so the computer took it.")
                
        if len(added_items) == 0:
            print("You didn't have that card, so you told the computer to GO FISH!")
            inum = game_deck.rando()
            if len(game_deck.card_deck) != 1:
                new_card = game_deck.get_card(inum)
                computer_hand.cards.append(new_card)
                game_deck.remove_card(inum)
            if len(game_deck.card_deck) == 1:
                last_card = game_deck.get_card(0)
                game_deck.remove_card(0)
                computer_hand.add_card(last_card)

                
class Deck:
    '''This object contains a list of cards that contains all the cards that would 
    be in a card deck.'''
    def __init__(self):
        value_list = [1,2,3,4,5,6,7,8,9,10,11,12,13]
        self.card_deck = []
        self.remaining_cards = 38
        for idx in range(1, 14):
            self.card = Card(idx)
            for i in range(1,5):
                self.card_deck.append(self.card)

            
    def get_card(self, inum):
        #This method returns a card based on the index passed in through the parameter "inum".
        card = self.card_deck[inum]
        return card
            
    def remove_card(self, idx):
        '''#This method removes a card from the deck using an index passed in
        through the parameter "idx".'''
        self.card_deck.pop(idx)
        
    def num_cards(self):
        #This method counts the number of cards in the deck.
        return len(self.card_deck)
        
    def rando(self):
        #This method returns a random index of a card in the deck.
        if len(self.card_deck) > 0:
            idx = random.randint(0, len(self.card_deck) - 1)
            return idx
        else:
            return False
        
    def deal(self, hand):
        #This method adds 8 random cards from the deck to a hand object that is a parameter.
        for i in range(1, 8):
            idx = self.rando()
            card = self.get_card(idx)
            hand.add_card(card)
            self.remove_card(idx)
        
        
class FishGame:
    #This object contains the framework for the game.
    def __init__(self):
        #Instances of other objects are contained in the FishGame object
        self.game_deck = Deck()
        self.player_hand = Hand()
        self.computer_hand = Hand()
        self.user_player = Player()
        self.opp_player = Computer()
        self.interfaces = GF_interfaces.GraphicInterface(self.game_deck, 
                        self.computer_hand, self.player_hand, self.user_player, self.opp_player)
    
    def play(self):
        '''This method plays the game. Its deals the cards. It lets each of the players 
        take their turns while the amount of cards in the deck is greater than 0. 
        Then it deisplays the final window based on on which player had the highest score.'''
    
        self.game_deck.deal(self.player_hand)
        self.game_deck.deal(self.computer_hand)
        remaining_cards = self.game_deck.num_cards()
        
        self.interfaces.intro_win()
        self.interfaces.main_win()
        while remaining_cards > 0:
            self.interfaces.update_window(self.game_deck, self.player_hand, 
            self.computer_hand, self.user_player, self.opp_player)
            print("________________________")
        
            
            self.user_player.ask_card(self.player_hand, self.computer_hand, self.game_deck)

            points = self.player_hand.create_book()
            self.user_player.add_score(points)
            score = self.user_player.get_score()
            #Case: One card left on player's turn and the player has no cards
            if self.game_deck.remaining_cards == 1 and self.player_hand.num_cards() == 0:
                last_card = self.game_deck.get_card(0)
                self.game_deck.remove_card(0)
                self.player_hand.add_card(last_card)
                points = self.player_hand.create_book()
                self.user_player.add_score(points)
                remaining_cards = 0
        
            else:
                remaining_cards = self.game_deck.num_cards()
                if remaining_cards != 0 and self.game_deck.remaining_cards != 1:
                    ivalue = self.opp_player.choose_card(self.computer_hand, self.game_deck)
                    self.opp_player.ask_card(self.player_hand, 
                                             self.computer_hand, self.game_deck, ivalue)
                    self.game_deck.remaining_cards = self.game_deck.num_cards()
                    points = self.computer_hand.create_book()
                    self.opp_player.add_score(points)
                    computer_score = self.opp_player.get_score()
                    remaining_cards = self.game_deck.num_cards()
                    num_computer = self.computer_hand.num_cards()
                    print("________________________")
                #Case: One card left on the computer's turn and the computer has no cards
                if self.game_deck.remaining_cards == 1:
                    last_card = self.game_deck.get_card(0)
                    self.game_deck.remove_card(0)
                    self.computer_hand.add_card(last_card)
                    points = self.computer_hand.create_book()
                    self.opp_player.add_score(points)
                    remaining_cards = 0
        #Updates the graphics one last time at the end            
        self.interfaces.update_window(self.game_deck, self.player_hand, 
            self.computer_hand, self.user_player, self.opp_player)
        #Runs various ending windows depending on the final scores
        
        if score > computer_score:
            print("You win!")
            self.interfaces.win_win()
            
        elif computer_score > score:
            print("You did NOT win¡")
            self.interfaces.lose_win()
            
        else:
            print("You tied~")
            self.interfaces.tie_win()

            
        