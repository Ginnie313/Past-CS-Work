'''Erika Mitchell and Ginnie White
Written March 8th 2018
This is code that imports GFClasses so that we can run all of 
our code from one nicely named py file'''

import GFClasses

def main():
    game = GFClasses.FishGame()
    game.play()
    
if __name__ == '__main__':
    main()