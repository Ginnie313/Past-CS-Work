Go Fish Game
By Erika Mitchell and Ginnie White


This program allows the user to play a Go Fish game against the computer. The user starts off at a intro window that will let the user click on a button to display the rules, or click anywhere else to start the game. It makes use of a scoreboard to show the player their current cards, score, the number of cards left in the deck, the number of cards in the computer's hand, and the computer's score. The player and the computer each take turns asking for cards and either taking them from the opponent's hand, or drawing from the deck. The game ends when there are no more cards left in the deck. Based on the scores at the end, different ending windows will play.


We wrote our code to utilize classes. There are two py files with classes--GF_interfaces and GFClasses. GF_interfaces has one class called GraphicInterface, which contains methods that will run each of the various windows for the game. It also has methods that will update the scoreboard to reflect the state of the game. GFClasses has multiple classes (Card, Hand, Player, Computer, Deck and FishGame) that perform the nuts and bolts of the game. Card Objects reflect the cards in the deck while a Hand is a player's current cards. The Card class's only method is to get its own value. The Hand class has an method to create a book once the player has 4 cards, and also methods to add and remove Cards as the game goes on. The Deck represents all cards still left in the game's deck throughout the game, so it has methods for removing and dealing Cards. The Player class and the Computer class are very similar, (both have methods to ask the opponent for a card and to get their score) but have different methods for choosing which card to ask for. Player asks the user, while Computer has an AI that chooses any cards it has three of first, then any two pairs, then a random card from the hand. FishGame runs most of the game from a while loop in the play method, which will keep running while there are still cards left in the deck. The scoreboard will also keep updating. When there are no more cards left, FishGame runs the ending windows and the game ends.


Currently everything in the game works to the best of our knowledge. We had a bug with the game not wanting to end properly if the players got down to 1 card left in the deck, but we've fixed it. 



HOW TO RUN GO FISH:

You can run it from the command line by running Go_Fish.py. As long as all the files are in the same folder, the game should work correctly. 



Image Sources:

https://you.stonybrook.edu/yuriehoriguchi/2017/05/11/final-project-storybased-epub-or-interactive-pdf/
https://wallpapercave.com/light-blue-backgrounds
http://clipart-library.com/animation-fish.html

