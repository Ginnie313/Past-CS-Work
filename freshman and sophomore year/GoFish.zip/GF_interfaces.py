'''Ginnie White and Erika Mitchell
Written March 8, 2018
This is code that create the graphic interfaces class used in the GoFish Game.'''

import graphics 

import GFClasses

#This is a class that contains all the graphics for the game
class GraphicInterface:
    #Initializes the class, takes in Deck, 2 Hand, Computer, and Player objects from GFClasses
    def __init__(self, game_deck, computer_hand, player_hand, player, player2):
        
        self.remaining = self.remaining_cards(game_deck)
        
        self.num_com = self.num_comp_cards(computer_hand)
        
        self.your_cards = self.current_cards(player_hand)
        
        self.score1 = self.your_score(player)
        
        self.score2 = self.computer_score(player2)

    #Creates the intro window that launches when the user starts the game    
    def intro_win(self):    
        self.win = graphics.GraphWin("Go Fish Intro", 400, 500)
        # transform coordinates
        self.win.setCoords(0, -20, 300, 300)
        
        #Creates an image background for the game
        self.fish_image = graphics.Image(graphics.Point(100, 100), "fish.gif")
        self.fish_image.draw(self.win)
        
        #Creates header with game name
        self.header = GraphicInterface.create_rectangle(50, 250, 250, 280, 'white')
        self.header.draw(self.win)
        self.message = graphics.Text(graphics.Point(155, 265), 'GO FISH!')
        self.message.setSize(30)
        self.message.setStyle("bold")
        self.message.draw(self.win)
        
        #Creates box with creator names and instructions on proceeding
        self.names = GraphicInterface.create_rectangle(50, -10, 250, 30, 'white')
        self.names.draw(self.win)
        self.message2 = graphics.Text(graphics.Point(155, 15), 'Click to Start!')
        self.message2.setSize(20)
        self.message2.setStyle("bold")
        self.message2.draw(self.win)
        self.message3 = graphics.Text(graphics.Point(155, 5), 'Game by Erika and Ginnie')
        self.message3.draw(self.win)
        
        #Creates a box that indicates this is the rules screen
        self.rules_box = GraphicInterface.create_rectangle(260, 255, 290, 275, 'white')
        self.rules_box.draw(self.win)
        self.rules_message = graphics.Text(graphics.Point(275, 265), 'Rules')
        self.rules_message.draw(self.win)
        self.mouse_position = self.win.getMouse()
        mp_x = self.mouse_position.getX()
        mp_y = self.mouse_position.getY()
        if (mp_x >= 250 and mp_x <= 280) and (mp_y >= 255 and mp_y  <= 275):
            self.rules_box.undraw()
            self.rules_message.undraw()
            self.rules_box.draw(self.win)
            self.rules_message.draw(self.win)
            GraphicInterface.rules_win()
        
        self.win.getMouse()
        self.win.close()
    
    #Creates the main window that contains the majority of the game
    def main_win(self):
        self.win = graphics.GraphWin("Go Fish Main Window", 400, 500)
        # transform coordinates
        self.win.setCoords(0, -20, 300, 300)
        self.fish_image = graphics.Image(graphics.Point(100, 100), "ocean.gif")
        self.fish_image.draw(self.win)
        
        #Creates a box that shows the user's current cards
        self.large_card_box = GraphicInterface.create_rectangle(50, 30, 250, 100, 'cyan')
        self.large_card_box.draw(self.win)
        self.small_card_box = GraphicInterface.create_rectangle(60, 40, 240, 90, 'white')
        self.small_card_box.draw(self.win)
        self.card_box = GraphicInterface.create_rectangle(105, 100, 195, 115, 'white')
        self.card_box.draw(self.win)
        self.card_message = graphics.Text(graphics.Point(150, 107), 'Your Current Cards:')
        self.card_message.setStyle("bold")
        self.card_message.draw(self.win)
        
        #Creates a box that shows how many cards are left in the deck
        self.deck_box = GraphicInterface.create_rectangle(85, 150, 215, 195,'cyan')
        self.deck_box.draw(self.win)
        self.deck_message = graphics.Text(graphics.Point(150, 185), 'Cards in Deck:')
        self.deck_message.draw(self.win)
        self.small_deck_box = GraphicInterface.create_rectangle(95, 155, 205, 180, 'white')
        self.small_deck_box.draw(self.win)
        
        #Creates a box that shows the player's score
        self.ps_box = GraphicInterface.create_rectangle(15, 150, 65, 195, 'cyan')
        self.ps_box.draw(self.win)
        self.ps_message = graphics.Text(graphics.Point(40, 185), 'Your Score:')
        self.ps_message.draw(self.win)
        self.small_ps_box = GraphicInterface.create_rectangle(20, 155, 60, 180, 'white')
        self.small_ps_box.draw(self.win)
        
        #Creates a box that shows the computer's score
        self.os_box = GraphicInterface.create_rectangle(220, 150, 300, 195, 'cyan')
        self.os_box.draw(self.win)
        self.os_message = graphics.Text(graphics.Point(260, 185), 'Computer Score:')
        self.os_message.draw(self.win)
        self.small_os_box = GraphicInterface.create_rectangle(230, 155, 290, 180, 'white')
        self.small_os_box.draw(self.win)
        
        #Creates a box that shows how many cards are in the computer's hand
        self.cnum_box = GraphicInterface.create_rectangle(100, 240, 200, 290,'cyan')
        self.cnum_box.draw(self.win)
        self.cnum_message = graphics.Text(graphics.Point(150, 275), 'Cards in Computer Hand:')
        self.cnum_message.draw(self.win)
        self.small_cnum_box = GraphicInterface.create_rectangle(110, 245, 190, 270, 'white')
        self.small_cnum_box.draw(self.win)
        
    #Creates a window that shows the rules of the game
    def rules_win():
        win = graphics.GraphWin("Go Fish Rules", 400, 500)
        # transform coordinates
        win.setCoords(0, -20, 300, 300)
        fish_image = graphics.Image(graphics.Point(100, 100), "rules.gif")
        fish_image.draw(win)
        box = GraphicInterface.create_rectangle(15, -10, 290, 290, 'white')
        box.draw(win)
        box = GraphicInterface.create_rectangle(25, 270, 280, 285, 'cyan')
        box.draw(win)
        rules_message = graphics.Text(graphics.Point(152, 276), 'THE RULES OF GO FISH')
        rules_message.setSize(24)
        rules_message.setStyle("bold")
        rules_message.draw(win)
        str1 = ("1. You get 7 cards to starts. You need 4 cards" + "\n" + 
                "with the same number value to earn a point.")
        message1 = graphics.Text(graphics.Point(152, 236), str1)
        message1.setSize(16)
        message1.draw(win)
        str2 = ("2. You go first, and can ask the computer for a card." + "\n" + 
                "If the computer has any cards of that value," + "\n" +
                "they must give them to you and your turn ends." + "\n" +
                "If the computer doesn't have the value requested" +
               "\n" + "you must " + "'Go Fish!'" + " , drawing a card from the deck." + "\n" 
                "Your turn then ends, and the computer" + "\n" + "takes its own turn.")
        message2 = graphics.Text(graphics.Point(152, 176), str2)
        message2.setSize(16)
        message2.draw(win)
        str3 = ("3. If you get 4 cards of the same value, your cards" + "\n" +
               "will be automatically converted into" + "\n" + "points added to your score.")
        message3 = graphics.Text(graphics.Point(152, 110), str3)
        message3.setSize(16)
        message3.draw(win)
        str4 = ("4. The game ends when there are no more cards" + "\n" +
               "left in the deck. If you have the most cards, you win!")
        message4 = graphics.Text(graphics.Point(152, 70), str4)
        message4.setSize(16)
        message4.draw(win)
        str5 = "Click to close"
        message5 = graphics.Text(graphics.Point(152, 40), str5)
        message5.setSize(16)
        message5.setTextColor("blue")
        message5.draw(win)
        win.getMouse()
        win.close() 
        
        #Creates a window that runs if the player wins
    def win_win(self):
        self.win = graphics.GraphWin("You Won!", 400, 500)
        # transform coordinates
        self.win.setCoords(0, -20, 300, 300)
        self.fish_image = graphics.Image(graphics.Point(100, 100), "fish.gif")
        self.fish_image.draw(self.win)
        self.header = GraphicInterface.create_rectangle(30, 250, 280, 280, 'white')
        self.header.draw(self.win)
        self.message = graphics.Text(graphics.Point(155, 265), 'You win! Thanks for playing.')
        self.message.setSize(24)
        self.message.setStyle("bold")
        self.message.setTextColor("blue")
        self.message.draw(self.win)
        self.win.getMouse()
        self.win.close()
    
    #Creates a window that runs if the player loses
    def lose_win(self):
        self.win = graphics.GraphWin("You Lost!", 400, 500)
        # transform coordinates
        self.win.setCoords(0, -20, 300, 300)
        self.fish_image = graphics.Image(graphics.Point(100, 100), "fish.gif")
        self.fish_image.draw(self.win)
        self.header = GraphicInterface.create_rectangle(30, 250, 280, 280, 'white')
        self.header.draw(self.win)
        self.message = graphics.Text(graphics.Point(155, 265), 'You lost! Oh no!')
        self.message.setSize(24)
        self.message.setStyle("bold")
        self.message.setTextColor("blue")
        self.message.draw(self.win)
        self.win.getMouse()
        self.win.close()
    
    #Creates a window that runs if the player ties
    def tie_win(self):
        self.win = graphics.GraphWin("You Tie", 400, 500)
        # transform coordinates
        self.win.setCoords(0, -20, 300, 300)
        self.fish_image = graphics.Image(graphics.Point(100, 100), "fish.gif")
        self.fish_image.draw(self.win)
        self.header = GraphicInterface.create_rectangle(30, 250, 280, 280, 'white')
        self.header.draw(self.win)
        self.message = graphics.Text(graphics.Point(155, 265), 'You tied! Try again!')
        self.message.setSize(24)
        self.message.setStyle("bold")
        self.message.setTextColor("blue")
        self.message.draw(self.win)
        self.win.getMouse()
        self.win.close()    
    
    #Function that takes in four points and color and returns a rectangle
    def create_rectangle(coord1, coord2, coord3, coord4, color):
        rect = graphics.Rectangle(graphics.Point(coord1, coord2), graphics.Point(coord3, coord4))
        rect.setFill(color)
        return rect
    
    '''Function that takes in the game_deck Deck object and returns a string with the number of
    cards left'''
    def remaining_cards(self, game_deck):
        deck_str = str(game_deck.num_cards())
        self.remaining = graphics.Text(graphics.Point(150, 165), deck_str)
        self.remaining.setSize(20)
        return self.remaining
    
    '''Takes in the computer_hand Hand object and returns a string with the number of
    cards left in the hand'''    
    def num_comp_cards(self, computer_hand):
        comp_str = str(computer_hand.num_cards())
        self.num_com = graphics.Text(graphics.Point(150, 257), comp_str)
        self.num_com.setSize(20)
        return self.num_com
       
    '''Takes in the player Player object and then returns the player's score as a string'''    
    def your_score(self, player):
        player_str = str(player.get_score())
        self.score1 = graphics.Text(graphics.Point(40, 165), player_str)
        self.score1.setSize(20)
        return self.score1
        
    '''Takes in the computer Computer object and then returns the computer's score as a string'''    
    def computer_score(self, player2):
        player_str = str(player2.get_score())
        self.score2 = graphics.Text(graphics.Point(260, 167), player_str)
        self.score2.setSize(20)
        return self.score2
        
    '''Takes in the player_hand Hand object and returns a string with the current cards'''    
    def current_cards(self, player_hand):
        player_str = str(player_hand.show_cards())
        self.your_cards = graphics.Text(graphics.Point(150, 65), player_str)
        self.your_cards.setSize(15)
        return self.your_cards
    
    '''Takes in a Deck object, two Hand objects, a Player object and a Computer object
    and then updates all the strings displayed to the player on the screen'''    
    def update_window(self, game_deck, player_hand, computer_hand, player, player2):
        list_methods = [self.remaining, self.num_com, self.score1, self.score2, self.your_cards]
        for item in list_methods:
            item.undraw()
        self.remaining.setText(game_deck.num_cards())
        self.num_com.setText(computer_hand.num_cards()) 
        self.score1.setText(player.get_score())
        self.score2.setText(player2.get_score())
        self.your_cards.setText(player_hand.show_cards())
        for item in list_methods:
            item.draw(self.win)
          